<?php
/**
 * Convert mysql datetime format to human readable date
 * @param  datetime $dateR 	the date that needs to be made readable	
 * @return string   		the date in Month day, Year format
 * @author  melissa <mcabral@platt.edu>
 * @since  0.1
 */
function convert_date($dateR){
	$engMon=array('January','February','March','April','May','June','July','August','September','October','November','December',' ');
	$l_months='January:February:March:April:May:June:July:August:September:October:November:December';
	$dateFormat='F j, Y';
	$months=explode (':', $l_months);
	$months[]='&nbsp;';
	$dfval=strtotime($dateR);
	$dateR=date($dateFormat,$dfval);
	$dateR=str_replace($engMon,$months,$dateR);
	return $dateR;
}
//no close php